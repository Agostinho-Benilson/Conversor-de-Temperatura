package com.example.exe1_tic;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {
    private  EditText temperatura;
    private TextView resultado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        temperatura = findViewById(R.id.temperatura);
        resultado = findViewById(R.id.resultado);

        temperatura.setText(" ");

    }


    public void converter(View view){
        DecimalFormat deci = new DecimalFormat("0.00");//para definir o limite de casas decimais.
        float celcius = Float.parseFloat(temperatura.getText().toString());
        double calculo = celcius * 1.8 + 32;
        resultado.setText("O seu equivalente em Fahrenheit: " +  deci.format(calculo));
    }


}